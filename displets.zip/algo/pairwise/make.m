mex('energyPairwiseMex.cpp');
mex('energyPairwiseNormalsMex.cpp');
disp('done!');
